#include <stdio>

int main() {
int a;

do
{
scanf("%d", &a);
} while (a < 1 || a > 3);

switch(a)
{
case 1:
do
{
scanf("%d", &a);
} while (a < 1 || a > 3);

switch(a)
{
case 1:
printf("CASO 1.1\n");
break;
case 2:
printf("CASO 1.2\n");
break;
case 3:
printf("CASO 1.3\n");
break;
}
break;
case 2:
printf("CASO 2\n");
break;
case 3:
printf("CASO 3\n");
break;
}

return 0;
}