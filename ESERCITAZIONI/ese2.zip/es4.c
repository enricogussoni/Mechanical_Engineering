#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// NOTA BENE
// Il rumore rumerico (legato alla rappresentazione di un numero, limitata nel numero di bit in un 
// computer) potrebbe far non convergere l'algoritmo. Per questo, utilizzarlo con numeri N relativiamente 
// piccoli e con accuratezze A larghe (tanto più grandi quanto più grande é il numero N).

int main() {
	int N, invio;					// osservazione: prima di essere 
	float r, A;						// usate queste variabili sono 
	float ris;						// inizializzate
	float min, max;					// bordo sinistro e destro correnti
	float iter_q_min, iter_q_max;	// quadrati di bordo sinistro e destro nell'iterazione
	float dec;						// decimali correnti; non int per non dover fare cast nelle divisioni
	float delta; 					// il delta massimo tra bordo sx e dx ed il numero N
	float err_sx, err_dx;			// delta tra corrente quadrato a sinistra e a destra
	int stop = 0;					// fine ricerca?

	// ipotesi di lavoro:
	do
	{
		printf("Inserisci N\n");
		scanf("%d", &N);
	} while (N<1);
	do
	{
		printf("Inserisci A\n");
		scanf("%f", &A);
	} while (A<0);
	

	min = 0;
	max = 1;
	dec = 1;

	while (stop != 1)
	{
		iter_q_min=min*min;
		iter_q_max=max*max;
		printf("min %f max %f\n", min, max);
		while (N >= iter_q_max || N <= iter_q_min)
		{
			min+=1.0/dec;
			max+=1.0/dec;
			iter_q_min=min*min;
			iter_q_max=max*max;
			printf("min %f max %f\n", min, max);
		}
		err_sx=N-iter_q_min;
		if (err_sx < 0)
			err_sx=-err_sx;
		err_dx=N-iter_q_max;
		if(err_dx < 0)
			err_dx=-err_dx;
		if (err_dx > err_sx)
			delta = err_dx;
		else
			delta = err_sx;
		if (delta <= A)
			stop = 1;
		else
		{
			dec*=10;
			max = min + 1.0/dec;
		}
		printf("dec %f err_sx %f err_dx %f delta %f\n", dec, err_sx, err_dx, delta);
	}

	ris = (min + max) / 2;
	printf ("%f\n", ris);

	return 0;
}