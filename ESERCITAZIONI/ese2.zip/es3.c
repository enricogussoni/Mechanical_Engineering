#include <stdio.h>
#include <math.h>

int main() {
	int N, primo; 	// osservazione: prima di essere 
					// usate queste variabili sono 
					// inizializzate

	// ipotesi di lavoro:
	// ipotizziamo che il numero inserito sia primo
	// se lo é, vuol dire che controlleremo tutti
	// i possibili divisori e nessuno di essi 
	// darà mod == 0. Altrimenti, assegnamo 0 a
	// primo ed usciamo dal for (early stop)
	// e !primo del while garantirà che andremo avanti

	do
	{
		scanf("%d", &N);
		// flag
		// a che stato del sistema é associato? 
		// all'aver già trovato o meno che il
		// numero N é primo.
		primo = 1;
		// calcolo primalità
		for (int divisore=floor(sqrt(N)); divisore>1 && primo; divisore--)
			if (N%divisore == 0)
				primo = 0;
	} while (primo==0);

	printf ("%d\n", N);

	return 0;
}