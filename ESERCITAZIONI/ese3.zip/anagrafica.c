struct data_s {
	int giorno;
	int mese;
	int anno;
};

struct persona_s {
	char nome[40];
	char cognome[40];
	struct data_s nascita;
	char cf[17];
};

typedef struct data_s data;
typedef struct persona_s persona;


int main(){
	int i=0, found=0;
	char cf[16];
	scanf("%s", &cf[0]);

	persona p[100];
	// caricamento
	for(i=0; i<100;i++)
	{
		scanf("%s", &(p[i].nome));
		scanf("%s", &(p[i].cognome);
		scanf("%d", &(p[i].nascita.giorno);
		scanf("%d", &(p[i].nascita.mese));
		scanf("%d", &(p[i].nascita.anno));
		scanf("%s", &(p[i].cf));
	}

	for (i=0; i<100 && found!=1; i++){
		if (strcmp(p[i].cf, cf)==0)
		{
			found = 1;
			printf("%s", p[i].nome);
			printf("%s", p[i].cognome);
			printf("%d", p[i].nascita.giorno);
			printf("%d", p[i].nascita.mese);
			printf("%d", p[i].nascita.anno);
			printf("%s", p[i].cf);
		}
	}
	if (found != 1)
		printf("errore");
	return 0;
}