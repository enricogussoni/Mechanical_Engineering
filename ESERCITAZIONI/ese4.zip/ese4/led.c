#include <stdio.h>

struct pixel_s {
	int r;
	int g;
	int b;
};
typedef struct pixel_s pixel;

#define M 1920
#define N 1080

int main() {
	
	pixel monitor[M][N];
	int i;
	int col;
	char ch;
	float avg;

	do
	{
		printf("Inserire una colonna del monitor\n");
		scanf("%d", &col);
	}while (col<0 || col>=N);

	do
	{
		printf("Inserire un canale del pixel\n");
		scanf(" %c", &ch);
	}while (ch != 'r' || ch != 'g' || ch != 'b');

	switch (ch)
	{
		case 'r':
			for (avg=0, i=0; i<M; i++)
				avg+=monitor[i][col].r;
			break;
		case 'g':
			for (avg=0, i=0; i<M; i++)
				avg+=monitor[i][col].g;
			break;
		case 'b':
			for (avg=0, i=0; i<M; i++)
				avg+=monitor[i][col].b;
			break;
	}
	printf("Il valor medio della colonna %d rispetto al canale %c é %f\n", col, ch, avg/N);
	
	return 0;
}