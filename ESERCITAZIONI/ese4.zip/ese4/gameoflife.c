#include <stdio.h>

#define M 6
#define N 6
#define K 2

/*******************************************

Attenzione: il codice é sostanzialmente 
corretto, ma é stato lasciato qua e la un 
bug, più alcune indicazioni alla fine 
del codice per fare ulteriore esercizio.
Utilizzate il seguente simulatore per 
verificare di avere corretto il bug!
http://www.bitstorm.org/gameoflife/

*******************************************/

int main() {
	
	// variables
	int boardt[M][N];
	int boardtt[M][N];
	int i,j,t;
	int vivi;

	// initialization 
	for (i=0; i<M; i++)
		for (j=0; j<N; j++)
			boardt[i][j]=0;

	// punti iniziali
	printf("Inserire ancora 4 coppie di valori iniziali di celle vive.\n");
	scanf("(%d,%d)",&i,&j);
	boardt[i][j]=1;
	printf("Inserire ancora 3 coppie di valori iniziali di celle vive.\n");
	scanf(" (%d,%d)",&i,&j);
	boardt[i][j]=1;
	printf("Inserire ancora 2 coppie di valori iniziali di celle vive.\n");
	scanf(" (%d,%d)",&i,&j);
	boardt[i][j]=1;
	printf("Inserire ancora 1 coppia di valori iniziali di celle vive.\n");
	scanf(" (%d,%d)",&i,&j);
	boardt[i][j]=1;

	// evolution
	for (t=0; t<K ; t++)
	{
		// print the state
		printf("\n");
		for (i=0; i<M; i++)
		{
			for (j=0; j<N; j++)
			{
				if (boardt[i][j]==1)
					printf("x");
				else
					printf("o");
			}
			printf("\n");
		}
		printf("\n");

		// higher border (NO corners)
		for (j=1, vivi=0; j<N-1; j++)
		{
			// stato dei vicini
			if (boardt[0][j-1]==1)
				vivi++;
			if (boardt[1][j-1]==1)
				vivi++;
			if (boardt[1][j]==1)
				vivi++;
			if (boardt[1][j+1]==1)
				vivi++;
			if (boardt[0][j+1]==1)
				vivi++;
			// regola 1
			if (vivi==3 && boardt[0][j]==0)
			{
				boardtt[0][j]=1;
			}
			// regola 2
			if ((vivi==2 || vivi ==3) && boardt[0][j]==1)
			{
				boardtt[0][j]=1;
			}
			// regola 3
			if (vivi<2 || vivi >3)
			{
				boardtt[0][j]=0;
			}
		}
		
		// lower border (NO corners)
		for (j=1, vivi=0; j<N-1; j++)
		{
			// stato dei vicini
			if (boardt[M-1][j-1]==1)
				vivi++;
			if (boardt[M-2][j-1]==1)
				vivi++;
			if (boardt[M-2][j]==1)
				vivi++;
			if (boardt[M-2][j+1]==1)
				vivi++;
			if (boardt[M-1][j+1]==1)
				vivi++;
			// regola 1
			if (vivi==3 && boardt[M-1][j]==0)
			{
				boardtt[M-1][j]=1;
			}
			// regola 2
			if ((vivi==2 || vivi==3) && boardt[M-1][j]==1)
			{
				boardtt[M-1][j]=1;
			}
			// regola 3
			if (vivi<2 || vivi >3)
			{
				boardtt[M-1][j]=0;
			}
		}
		
		// left border (NO corners)
		for (i=1, vivi=0; i<M-1; i++)
		{
			// stato dei vicini
			if (boardt[i-1][0]==1)
				vivi++;
			if (boardt[i-1][1]==1)
				vivi++;
			if (boardt[i][1]==1)
				vivi++;
			if (boardt[i+1][1]==1)
				vivi++;
			if (boardt[i+1][0]==1)
				vivi++;
			// regola 1
			if (vivi==3 && boardt[i][0]==0)
			{
				boardtt[i][0]=1;
			}
			// regola 2
			if ((vivi==2 || vivi ==3) && boardt[i][0]==1)
			{
				boardtt[i][0]=1;
			}
			// regola 3
			if (vivi<2 || vivi >3)
			{
				boardtt[i][0]=0;
			}
		}
		
		// right border (NO corners)
		for (i=1, vivi=0; i<M-1; i++)
		{
			// stato dei vicini
			if (boardt[i-1][N-1]==1)
				vivi++;
			if (boardt[i-1][N-2]==1)
				vivi++;
			if (boardt[i][N-2]==1)
				vivi++;
			if (boardt[i+1][N-2]==1)
				vivi++;
			if (boardt[i+1][N-1]==1)
				vivi++;
			// regola 1
			if (vivi==3 && boardt[i][N-1]==0)
			{
				boardtt[i][N-1]=1;
			}
			// regola 2
			if ((vivi==2 || vivi ==3) && boardt[i][N-1]==1)
			{
				boardtt[i][N-1]=1;
			}
			// regola 3
			if (vivi<2 || vivi >3)
			{
				boardtt[i][N-1]=0;
			}
		}
		
		// upper left corner
		vivi = 0;
		vivi += boardt[0][1];
		vivi += boardt[1][1];
		vivi += boardt[1][0];
		// regola 1
		if (vivi==3 && boardt[0][0]==0)
		{
			boardtt[0][0]=1;
		}
		// regola 2
		if ((vivi==2 || vivi ==3) && boardt[0][0]==1)
		{
			boardtt[0][0]=1;
		}
		// regola 3
		if (vivi<2 || vivi >3)
		{
			boardtt[0][0]=0;
		}
		
		// upper right corner
		vivi = 0;
		vivi += boardt[0][N-2];
		vivi += boardt[1][N-2];
		vivi += boardt[1][N-1];
		// regola 1
		if (vivi==3)
		{
			boardtt[0][N-1]=1;
		}
		// regola 2
		if (vivi==2 || vivi ==3)
		{
			boardtt[0][N-1]=1;
		}
		// regola 3
		if (vivi<2 || vivi >3)
		{
			boardtt[0][N-1]=0;
		}
		
		// lower right corner
		vivi = 0;
		vivi += boardt[M-1][N-2];
		vivi += boardt[M-2][N-2];
		vivi += boardt[M-2][N-1];
		// regola 1
		if (vivi==3)
		{
			boardtt[M-1][N-1]=1;
		}
		// regola 2
		if (vivi==2 || vivi ==3)
		{
			boardtt[M-1][N-1]=1;
		}
		// regola 3
		if (vivi<2 || vivi >3)
		{
			boardtt[M-1][N-1]=0;
		}
		
		// lower left corner
		vivi = 0;
		vivi += boardt[M-2][0];
		vivi += boardt[M-2][1];
		vivi += boardt[M-1][1];
		// regola 1
		if (vivi==3)
		{
			boardtt[M-1][0]=1;
		}
		// regola 2
		if (vivi==2 || vivi ==3)
		{
			boardtt[M-1][0]=1;
		}
		// regola 3
		if (vivi<2 || vivi >3)
		{
			boardtt[M-1][0]=0;
		}
		
		// all the others
		for (i=1; i<M-1; i++)
		{
			for (j=1, vivi=0; j<N-1; j++)
			{
				// controlliamo gli 8 vicini
				if (boardt[i-1][j-1] == 1)
					vivi++;
				if (boardt[i-1][j] == 1)
					vivi++;
				if (boardt[i-1][j+1] == 1)
					vivi++;
				if (boardt[i][j-1] == 1)
					vivi++;
				if (boardt[i][j+1] == 1)
					vivi++;
				if (boardt[i+1][j-1] == 1)
					vivi++;
				if (boardt[i+1][j] == 1)
					vivi++;
				if (boardt[i+1][j+1] == 1)
					vivi++;
				// regola 1
				if (vivi==3)
				{
					boardtt[i][j]=1;
				}
				// regola 2
				if (vivi==2 || vivi ==3)
				{
					boardtt[i][j]=1;
				}
				// regola 3
				if (vivi<2 || vivi >3)
				{
					boardtt[i][j]=0;
				}
			}
		}
		
		// copy new state in old board
		for (i=0; i<M-1; i++)
			for (j=0, vivi=0; j<N-1; j++)
				boardt[i][j]=boardtt[i][j];
		
		
	}

	// print the state
	printf("\n");
	for (i=0; i<M; i++)
	{
		for (j=0; j<N; j++)
		{
			if (boardt[i][j]==1)
				printf("x");
			else
				printf("o");
		}
		printf("\n");
	}
	printf("\n");

}

// esercizio: semplificare il codice
// spunti:
// 1) ci sono regole semplificabili?
// 2) si può semplificare "l'algoritmo"/"idea"? O questo é l'unico modo di risolvere il problema?