#include <stdio.h>

struct prezzo_s {
	float iva;
	float netto;
};
typedef struct prezzo_s prezzo;

struct piatto_s {
	char ingr1[100];
	char ingr2[100];
	char ingr3[100];
	char ricetta[10000];
	prezzo p;
};

typedef piatto_s piatto;

struct menu_s{
	piatto primi[15];
	piatto secondi[15];
	piatto dolci[15];
	int num_primi;
	int num_secondi;
	int num_dolci;
};
typedef struct menu_s menu;

// domanda: potevamo inveritre la
// definizione di struct piatto_s e 
// struct mensu_s?

int main() {

	menu m;
	piatto eco;
	int i;
	int trovato_piatto_pasta;
	// init menu

	// trovo il primo piatto di pasta primo prezzo nel menu; é il nostro piatto di riferimento
	for (i=0, trovato_piatto_pasta=0; i<m.num_primi && !trovato_piatto_pasta; i++)
	{
		if (strcmp(m.primi[i].ingr1, "pasta") == 0 ||
		    strcmp(m.primi[i].ingr2, "pasta") == 0 ||
		    strcmp(m.primi[i].ingr3, "pasta") == 0)
		{
			eco = m.primi[i]; // copia!
			trovato_piatto_pasta = 1;
		}
	}

	if (trovato_piatto_pasta == 1)
		for (i=0; i<m.num_primi; i++)
		{
			if (strcmp(m.primi[i].ingr1, "pasta") == 0 ||
		    	strcmp(m.primi[i].ingr2, "pasta") == 0 ||
		    	strcmp(m.primi[i].ingr3, "pasta") == 0)
			{
				if (m.primi[i].prezzo*(1+m.primi[i].iva) < eco.prezzo*(1+eco.iva))
					eco = m.primi[i];
			}

		}
	else
	{
		printf("Non ci sono piatti di pasta.\n");
		return 0;
	}

	// print eco

	return 0;
}