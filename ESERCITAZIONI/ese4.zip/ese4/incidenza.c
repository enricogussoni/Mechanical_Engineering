#include <stdio.h>

#define N 100

int main()
{
	int m[N][N];
	int i,j;
	int ct=0;

	do {
		scanf("(%d,%d)", &i, &j)
		if (i!=-1 && j!= -1)
			m[i][j]=1;
		ct++;
	} while (ct<N || (i==-1 && j== -1));

	for (i=0; i<N; i++){
		for (j=0; j<N; j++)
		{
			printf("%d ", m[i][j]);
		}
		printf ("\n");
	}
	
	return 0;
}